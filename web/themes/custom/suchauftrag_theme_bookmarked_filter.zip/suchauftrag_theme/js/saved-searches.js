/**
 * saved-searches.js
 * Vanilla JS only — no jQuery.
 *
 * Single source of truth for "which node ids has this visitor
 * bookmarked" — stored ONLY in the visitor's own browser localStorage.
 * No Drupal field, View filter value, or database table is written by
 * this file.
 *
 * Drupal.suchauftragSavedSearches (defined below) is read by two
 * other files, both lazily (inside event handlers/attach() calls,
 * never at parse time, so load order between all three files never
 * matters):
 *   - js/theme.js's bookmark-button click handler (a card's bookmark
 *     icon) — toggle()/isSaved().
 *   - js/search-ajax.js's "Nur gemerkte anzeigen" toggle — getAll(),
 *     read at request time and sent to the search_requests View as a
 *     real "bookmarked" exposed filter (views.view.search_requests.
 *     yml's exposed nid/"in" filter) alongside every other active
 *     filter/sort, then reloaded from the server via the existing
 *     Views AJAX pipeline. See search-ajax.js's own header comment
 *     for the full request/response details — this file no longer
 *     does any filtering itself.
 */
(function (Drupal) {
  'use strict';

  var STORAGE_KEY = 'suchauftrag:savedSearchNodeIds';

  /** Reads the saved id list from localStorage. Never throws — a disabled/unavailable localStorage (private browsing edge cases, quota errors) degrades to "nothing saved" rather than breaking the page. */
  function readSavedIds() {
    try {
      var raw = window.localStorage.getItem(STORAGE_KEY);
      var parsed = raw ? JSON.parse(raw) : [];
      return Array.isArray(parsed) ? parsed.map(String) : [];
    }
    catch (e) {
      return [];
    }
  }

  /** Writes the saved id list back to localStorage. Silently no-ops on failure (see readSavedIds). */
  function writeSavedIds(ids) {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(ids));
    }
    catch (e) {
      // Nothing further to do — bookmarking simply won't persist this
      // session, but the click still updates the on-screen icon state
      // via the caller, so the UI doesn't look broken.
    }
  }

  /**
   * Small shared API — used by js/theme.js's bookmark-button click
   * handler and by js/search-ajax.js's "Nur gemerkte anzeigen" toggle.
   */
  Drupal.suchauftragSavedSearches = {
    isSaved: function (nodeId) {
      return readSavedIds().indexOf(String(nodeId)) !== -1;
    },
    /** Adds/removes nodeId from the saved list and persists it. Returns the NEW saved state (true = now saved). */
    toggle: function (nodeId) {
      nodeId = String(nodeId);
      var ids = readSavedIds();
      var index = ids.indexOf(nodeId);
      var nowSaved;
      if (index === -1) {
        ids.push(nodeId);
        nowSaved = true;
      }
      else {
        ids.splice(index, 1);
        nowSaved = false;
      }
      writeSavedIds(ids);
      return nowSaved;
    },
    getAll: readSavedIds,
  };

})(Drupal);
